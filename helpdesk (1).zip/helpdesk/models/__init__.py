# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import digest
from . import helpdesk
from . import helpdesk_ticket
from . import res_users
from . import res_partner
